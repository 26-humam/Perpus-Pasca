<div class="row">
	<div class="col m 12">
		<h5>Profil Perpustakaan Pasca Sarjana UIN SGD Bandung</h5>
	</div>
</div>

<div class="row">
	<div class="col m6">
		<div class="card-panel teal darken-2 white-text">
			<h6><b>Visi</b></h6>
			<p>
			<i>"Menuju Smart Library 2025 yang Unggul dan Kompetitif di Asean"</i>
			</p><br>
			<h6><b>Misi</b></h6>
			<li>
				1.Mengembangkan perpustakaan keislaman dan keilmuan berbasis smart technology.
			</li>
			<li>
				2.Memberikan layanan kepada pengguna perpustakaan sesuai dengan perkembangan teknologi informasi.
			</li>
			<li>
				3.Meningkatkan kerjasama dengan berbagai pihak yang terkait untuk membangun kepercayaan dalam rangka peningkatan layanan.
			</li>

		</div>
	</div>
    <div class="col m6">
        <div class="card-panel teal darken-2 white-text">
            <h6><b>Tujuan Perpustakaan</b></h6><hr>
            <p>
			1.Menyelenggarakan pelayanan perpustakaan keislaman dan keilmuan berbasis smart technology.
<p>2.Menyelenggarakan layanan kepada pengguna perpustakaan sesuai dengan perkembangan teknologi informasi.
<p>3.Mengadakan kerjasama dengan berbagai pihak yang terkait untuk membangun kepercayaan dalam rangka peningkatan layanan.
            </p>
        </div>
    </div>
</div>
